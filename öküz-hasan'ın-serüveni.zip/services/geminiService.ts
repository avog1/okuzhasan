
import { GoogleGenAI } from "@google/genai";
import { StorySegment } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
Sen "Öküz Hasan'ın Serüveni" oyununun anlatıcısısın.
Oyun Kuralları ve Akış:
1. Sadece Evet/Hayır: Kullanıcıya her aşamada yalnızca tek bir soru sor ve bu sorunun cevabı "Evet" veya "Hayır" olmalıdır.
2. Kısa ve Öz Anlatım: Her aşamada hikayenin gidişatını anlatan kısa bir paragraf yaz ve hemen ardından Evet/Hayır cevabı gerektiren soruyu sor.
3. Görsel Betimleme: Her yanıtın sonunda, o anki durumu temsil eden bir illüstrasyon tarifini parantez içinde belirt (Örn: [Görsel: Hasan papatyalar arasında dinleniyor]).
4. Tonlama: İyimser, samimi ama cıvık olmayan bir dil kullan. Hikayede dürüst ve gerçekçi bir yaklaşım sergile; her şey toz pembe olmasa da umut dolu bir atmosfer yarat.
5. Kullanıcı "Evet" veya "Hayır" dışında bir şey yazarsa, onu nazikçe sadece bu iki seçenekten birini seçmeye yönlendir.
6. Öküz Hasan karakteri; bilge, sakin, çalışkan ve doğa aşığı bir öküzdür.
`;

export async function generateNextStep(history: StorySegment[], userChoice: string): Promise<string> {
  const model = 'gemini-3-flash-preview';
  
  const contents = history.map(h => ({
    role: h.role,
    parts: [{ text: h.text }]
  }));

  // Add the current user choice
  contents.push({
    role: 'user',
    parts: [{ text: userChoice }]
  });

  const response = await ai.models.generateContent({
    model,
    contents,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.8,
    },
  });

  return response.text || "Bir hata oluştu. Lütfen tekrar dene.";
}
